﻿using ClientManagementSystem.Models.Resources;
using System;
using System.Collections.Generic;
using System.Text;

namespace ClientManagementSystem.Models.Softwares.UpkeepSolution
{
    public class UpkeepSolution : PurchasedSoftware
    {

        public List<UpkeepLicense> Licenses { get; set; }
    }
       
}
