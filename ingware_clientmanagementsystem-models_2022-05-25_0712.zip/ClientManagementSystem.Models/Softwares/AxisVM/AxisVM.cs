﻿using ClientManagementSystem.Models.Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientManagementSystem.Models.Softwares.AxisVM
{
    public class AxisVM : PurchasedSoftware
    {
        public Guid AxisVMCalculationParametersId;
        public List<AxisVMLicense> Dongles { get; set; }       
       
    }
}
