﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static ClientManagementSystem.Models.CMSEnums;

namespace ClientManagementSystem.Models.Softwares.AxisVM
{
    public class AxisVMLicense
    {
        public int LicenseNumber { get; set; }
        public EAxisVMLicenseType LicenseType { get; set; }
        public int NumberOfLicensePlaces { get; set; }
        public bool SmallBusiness { get; set; }
        public DateTime PurchaseDate { get; set; }
        public DateTime ValidityPeriod { get; set; }
        public DateTime CanceledAt { get; set; }
        public string ArticleNumber { get; set; }
        public double Discount { get; set; }
        public string Comment { get; set; }          

    }

}

