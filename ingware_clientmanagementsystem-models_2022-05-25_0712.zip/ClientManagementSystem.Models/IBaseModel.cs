﻿using System;

namespace ClientManagementSystem.Models
{
    public interface IBaseModel
    {
        Guid Id { get; set; }
    }
}