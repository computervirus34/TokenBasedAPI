﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientManagementSystem.Models
{
    public class CMSEnums
    {
        public enum ECourseType
        {
            online,
            presencial,
            both
        }
        public enum EAxisVMLicenseType
        {
            network,
            local,
            software,
            hardware
        }
        public enum EAxisVMModuleType
        {
            basemodule,
            additionalmodule,
        }
        public enum EIngwareCompany
        {
            [Description("Ingware AG")] IngwareAG,
            [Description("Ingware Romandie")] IngwareRomandie,
        }
    }
}
