﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientManagementSystem.Models.Resources
{
    public class PurchasedSoftware : BaseModel 
    {
        public Guid ClientId;

        public Guid SoftwareId;
        public DateTime PurchaseDate { get; set; }


    }
}
