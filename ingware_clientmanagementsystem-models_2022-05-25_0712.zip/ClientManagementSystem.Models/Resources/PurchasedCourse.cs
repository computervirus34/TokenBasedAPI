﻿using System;
using System.Collections.Generic;
using System.Text;
using static ClientManagementSystem.Models.CMSEnums;

namespace ClientManagementSystem.Models.Resources
{
    public class PurchasedCourse : BaseModel
    {
        public Guid ClientId;
        public Guid CourseId { get; set; }
        public ECourseType Type { get; set; }
        public DateTime PurchaseDate { get; set; }
        public DateTime ExecutionDate { get; set; }
        public string Instructor { get; set; }
        public bool Executed { get; set; }


    }
}
