﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientManagementSystem.Models.Resources.AxisVM
{
    public class AxisVMCalculationParameters : BaseModel
    {
        public List<CurrencyDependentCalculationParameters> currencyDependantCalculationParams { get; set; }
        public double NetworkSurcharge { get; set; }
        public double PercentageReductionForSmallBusiness { get; set; }

    }
}
