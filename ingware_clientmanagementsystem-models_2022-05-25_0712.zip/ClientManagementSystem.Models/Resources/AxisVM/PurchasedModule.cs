﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientManagementSystem.Models.Resources.AxisVM
{
    public class PurchasedModule : BaseModel
    {
        public Guid ModuleId;
        public Guid ClientId;
        public Guid SoftwareId;
        public int DongleNumber;
        public DateTime PurchaseDate { get; set; }
        public double TablePrice { get; set; }
        public int Rank { get; set; }
    }
}
