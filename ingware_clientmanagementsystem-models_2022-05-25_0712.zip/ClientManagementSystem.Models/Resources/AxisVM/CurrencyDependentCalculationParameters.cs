﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientManagementSystem.Models.Resources.AxisVM
{
    public class CurrencyDependentCalculationParameters
    {
        public Guid CurrencyId { get; set; }
        public double PercentageSoftwareMaintenance { get; set; }
        public double[] PercentageDiscountByLicense { get; set; }
        public double NetworkSoftwareMaintenanceLimit { get; set; }
        public double LocalSoftwareMaintenanceLimit { get; set; }
    }
}
