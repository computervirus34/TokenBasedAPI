﻿using System;
using System.Collections.Generic;
using System.Text;
using static ClientManagementSystem.Models.CMSEnums;

namespace ClientManagementSystem.Models.Resources.AxisVM
    {
    public class Module : BaseModel
    {
        public EAxisVMModuleType Type { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public List<Price> Prices { get; set; }
    }
}
