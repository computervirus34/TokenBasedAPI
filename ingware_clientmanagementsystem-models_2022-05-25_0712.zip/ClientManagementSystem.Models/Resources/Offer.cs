﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientManagementSystem.Models.Resources
{
    public class Offer : BaseModel
    {      
        public Guid ClientId { get; set; }
        private bool Accepted { get; set; }    
     
    }
}
