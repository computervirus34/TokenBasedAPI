﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ClientManagementSystem.Models
{
    public class ClientModel : BaseModel
    {
        [Required(AllowEmptyStrings = false, ErrorMessage = "Client must have a company name")]
        public string CompanyName { get; set; }
        public string Location { get; set; }
        public int IngwareCompanyId { get; set; }
        public Guid CurrencyId { get; set; }
        public string ClientNumber { get; set; }

    }
}
