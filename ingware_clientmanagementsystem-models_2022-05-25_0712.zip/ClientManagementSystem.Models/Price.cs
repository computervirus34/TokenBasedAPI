﻿using System;
using System.Collections.Generic;
using System.Text;
using static ClientManagementSystem.Models.CMSEnums;

namespace ClientManagementSystem.Models
{
    public class Price
    {
        public Price(string currencycode, double value)
        {
            CurrencyCode = currencycode;
            Value = value;
        }
        public double Value { get; set; }
        public string CurrencyCode { get; set; }
    }
}
